<?php

require MODX_CORE_PATH . 'model/modx/modparser.class.php';